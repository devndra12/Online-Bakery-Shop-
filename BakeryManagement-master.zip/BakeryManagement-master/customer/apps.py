from django.apps import AppConfig


class CustomerConfig(AppConfig):
    name = 'customer'
